
from flask import Flask, jsonify, request
import json
import os
from datetime import datetime
from utils import load_events, save_events, validate_event

app = Flask(__name__)
DATA_FILE = 'events.json'

# Initialize file if not present
if not os.path.exists(DATA_FILE):
    with open(DATA_FILE, 'w') as f:
        json.dump([], f)

@app.route('/events', methods=['POST'])
def create_event():
    data = request.json
    is_valid, msg = validate_event(data)
    if not is_valid:
        return jsonify({'error': msg}), 400

    events = load_events()
    data['id'] = len(events) + 1
    events.append(data)
    save_events(events)
    return jsonify({'message': 'Event created', 'event': data}), 201

@app.route('/events', methods=['GET'])
def list_events():
    events = load_events()
    sorted_events = sorted(events, key=lambda x: x['start_time'])
    return jsonify(sorted_events), 200

@app.route('/events/<int:event_id>', methods=['PUT'])
def update_event(event_id):
    events = load_events()
    for event in events:
        if event['id'] == event_id:
            update_data = request.json
            event.update(update_data)
            save_events(events)
            return jsonify({'message': 'Event updated', 'event': event}), 200
    return jsonify({'error': 'Event not found'}), 404

@app.route('/events/<int:event_id>', methods=['DELETE'])
def delete_event(event_id):
    events = load_events()
    updated_events = [e for e in events if e['id'] != event_id]
    if len(updated_events) == len(events):
        return jsonify({'error': 'Event not found'}), 404
    save_events(updated_events)
    return jsonify({'message': f'Event {event_id} deleted'}), 200

if __name__ == '__main__':
    app.run(debug=True)
