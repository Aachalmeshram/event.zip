import json
from datetime import datetime

DATA_FILE = 'events.json'

def load_events():
    with open(DATA_FILE, 'r') as f:
        return json.load(f)

def save_events(events):
    with open(DATA_FILE, 'w') as f:
        json.dump(events, f, indent=2)

def validate_event(data):
    required_fields = ['title', 'description', 'start_time', 'end_time']
    for field in required_fields:
        if field not in data:
            return False, f'Missing field: {field}'

    try:
        start = datetime.fromisoformat(data['start_time'])
        end = datetime.fromisoformat(data['end_time'])
        if end <= start:
            return False, 'End time must be after start time.'
    except ValueError:
        return False, 'Invalid datetime format. Use ISO 8601.'

    return True, ''
