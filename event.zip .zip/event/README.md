# Event Scheduler System

A simple Flask-based backend for scheduling events.

## Features

- Create, Read, Update, Delete (CRUD) for events
- Events saved to a file (`events.json`)
- Data persists across sessions
- Postman collection included

## Setup

```bash
git clone <your-repo-url>
cd event_scheduler
pip install -r requirements.txt
python app.py
