# tests/test_app.py

import pytest
from app import app
import json

@pytest.fixture
def client():
    app.config['TESTING'] = True
    with app.test_client() as client:
        yield client

def test_create_event(client):
    response = client.post('/events', json={
        "title": "Test Event",
        "description": "This is a test.",
        "start_time": "2025-07-01T10:00:00",
        "end_time": "2025-07-01T11:00:00"
    })
    assert response.status_code == 201
    data = response.get_json()
    assert 'event' in data
    assert data['event']['title'] == "Test Event"

def test_get_events(client):
    response = client.get('/events')
    assert response.status_code == 200
    assert isinstance(response.get_json(), list)

def test_update_event(client):
    # First, create an event
    create = client.post('/events', json={
        "title": "To Be Updated",
        "description": "Update this",
        "start_time": "2025-07-01T12:00:00",
        "end_time": "2025-07-01T13:00:00"
    })
    event_id = create.get_json()['event']['id']

    # Then, update it
    update = client.put(f'/events/{event_id}', json={
        "title": "Updated Title"
    })
    assert update.status_code == 200
    assert update.get_json()['event']['title'] == "Updated Title"

def test_delete_event(client):
    # First, create an event
    create = client.post('/events', json={
        "title": "To Be Deleted",
        "description": "Delete this",
        "start_time": "2025-07-01T14:00:00",
        "end_time": "2025-07-01T15:00:00"
    })
    event_id = create.get_json()['event']['id']

    # Then, delete it
    delete = client.delete(f'/events/{event_id}')
    assert delete.status_code == 200
    assert "deleted" in delete.get_json()['message']
